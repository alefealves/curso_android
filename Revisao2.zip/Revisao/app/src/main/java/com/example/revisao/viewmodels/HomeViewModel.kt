package com.example.revisao.viewmodels

import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel
import com.example.revisao.models.User

class HomeViewModel : ViewModel(){

    var user = ObservableField<User>()

}