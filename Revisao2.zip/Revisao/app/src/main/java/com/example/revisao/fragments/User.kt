package com.example.revisao.fragments

import androidx.fragment.app.Fragment
import com.example.revisao.R

class User : Fragment(R.layout.user)