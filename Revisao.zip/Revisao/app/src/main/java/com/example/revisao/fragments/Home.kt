package com.example.revisao.fragments

import androidx.fragment.app.Fragment
import com.example.revisao.R

class Home : Fragment(R.layout.home)