package com.andersonk.androidcourse

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import kotlinx.android.synthetic.main.activity_stack.*
import kotlinx.android.synthetic.main.content_stack.*

class StackActivity : AppCompatActivity() {

    private val mainNavController: NavController? by lazy {
        findNavController(R.id.container_fragment)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stack)
        setSupportActionBar(toolbar)

        mainNavController?.let { nav.setupWithNavController(it) }
    }

}
