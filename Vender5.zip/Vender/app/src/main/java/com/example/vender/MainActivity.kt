package com.example.vender

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.navigation.fragment.NavHostFragment
import com.example.vender.features.UserSessionViewModel
import com.example.vender.utils.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var finalHost: NavHostFragment
    private var isLogged : Boolean = false
    lateinit var bottomNavigationView : BottomNavigationView
    private val viewModel: UserSessionViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottomNavigationView = findViewById<BottomNavigationView>(R.id.nav)

        setup()

        viewModel.authenticationState.observe(this, Observer { authenticationState ->
            when (authenticationState) {
                UserSessionViewModel.AuthenticationState.AUTHENTICATED ->{
                    mainFlow()
                }
                UserSessionViewModel.AuthenticationState.UNAUTHENTICATED ->{loginFlow()}
            }
        })

       
    }

    private fun clearHostContainer() {
        supportFragmentManager.fragments.forEach {
            supportFragmentManager
                .beginTransaction()
                .remove(it)
                .commitNow()
        }
    }

    /*private fun mainFlow() {
        clearHostContainer()

        bottomNavigationView.visibility = View.VISIBLE

        val navGraphIds = listOf(R.navigation.home_graph, R.navigation.settings_graph)

        // Setup the bottom navigation view with a list of navigation graphs
        val controller = bottomNavigationView.setupWithNavController(
            navGraphIds = navGraphIds,
            fragmentManager = supportFragmentManager,
            containerId = R.id.host_main,
            intent = intent
        )
    }

    private fun loginFlow() {
        clearHostContainer()

        bottomNavigationView.visibility = View.GONE

        if (!::finalHost.isInitialized) {
            finalHost = NavHostFragment.create(R.navigation.auth_graph)
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.host_login, finalHost)
            .setPrimaryNavigationFragment(finalHost) // this is the equivalent to app:defaultNavHost="true"
            .commit()
    }*/

    private fun setup() {
        val navGraphIds = listOf(R.navigation.home_graph, R.navigation.settings_graph)

        // Setup the bottom navigation view with a list of navigation graphs
        bottomNavigationView.setupWithNavController(
            navGraphIds = navGraphIds,
            fragmentManager = supportFragmentManager,
            containerId = R.id.host_main,
            intent = intent
        )

        // checar se nao foi inicializado
        if (!::finalHost.isInitialized) {
            finalHost = NavHostFragment.create(R.navigation.auth_graph)
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.host_login, finalHost)  // pegeui da navigation auth_graph (
            .setPrimaryNavigationFragment(finalHost) // this is the equivalent to app:defaultNavHost="true"
            .commitNow()
    }

    private fun mainFlow() {
        bottomNavigationView.visibility = View.VISIBLE
        host_login.visibility = View.GONE
        host_main.visibility = View.VISIBLE
        // fim
    }

    private fun loginFlow() {
        bottomNavigationView.visibility = View.GONE
        host_main.visibility = View.GONE
        host_login.visibility = View.VISIBLE
    }
}
