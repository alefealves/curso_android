package com.example.vender.features.home


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager

import com.example.vender.R
import com.example.vender.features.products.ProdutoAdapter
import com.example.vender.models.Produto
import kotlinx.android.synthetic.main.fragment_home.*

class HomeFragment : Fragment() {

    val produtoAdapter =
        ProdutoAdapter(mutableListOf<Produto>())

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val viewManager = LinearLayoutManager(activity)

        produtoAdapter.setData(initTodos())

        produtos_list.layoutManager = viewManager
        produtos_list.adapter = produtoAdapter
    }


    private fun initTodos(): MutableList<Produto>{
        val prod1 = Produto("1","Product 1",1,"img1")
        val prod2 = Produto("2","Product 2",2,"img2")
        val prod3 = Produto("3","Product 3",3,"img3")

        val produtos = mutableListOf(prod1, prod2, prod3)
        return produtos
    }

}
