package com.example.vender.models

data class Produto(var id : String, var name : String, var price : Int, var imageUrl : String){}