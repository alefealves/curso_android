package com.example.vender.features.products

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.vender.R
import com.example.vender.features.home.HomeFragmentDirections
import com.example.vender.models.Produto
import kotlinx.android.synthetic.main.lista_produtos.view.*

class ProdutoAdapter(private val produtos : MutableList<Produto>) : RecyclerView.Adapter<ProdutoAdapter.ProdutoViewHolder>() {

    fun addTodo(produto: Produto) {
        this.produtos.add(produto)
        notifyDataSetChanged()
    }

    fun setData(todos: List<Produto>){
        this.produtos.addAll(todos)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProdutoViewHolder {

        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.lista_produtos, parent, false)

        val viewHolder = ProdutoViewHolder(view)

        //faz a chamada
        view.setOnClickListener {
            it.findNavController().navigate(HomeFragmentDirections.navToDetail(1))
        }

        return viewHolder
    }

    override fun onBindViewHolder(holder: ProdutoViewHolder, position: Int) {

        val produto = produtos[position]
        holder.bindData(produto)
    }

    override fun getItemCount(): Int {
        return produtos.size
    }

    class ProdutoViewHolder( val view: View) : RecyclerView.ViewHolder(view) {

        fun bindData(produto: Produto) {

            view.name.text = produto.name
            view.price.text = produto.price.toString()
            view.imageUrl.text = produto.imageUrl

        }
    }
}