package com.example.vender.features.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.vender.R
import com.example.vender.models.Produto
import kotlinx.android.synthetic.main.lista_produtos.view.*

class ProdutoAdapter(private val produtos : MutableList<Produto>) : RecyclerView.Adapter<ProdutoAdapter.ProdutoViewHolder>() {

    fun addTodo(produto: Produto) {
        this.produtos.add(produto)
        notifyDataSetChanged()
    }

    fun setData(todos: List<Produto>){
        this.produtos.addAll(todos)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProdutoViewHolder {

        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.lista_produtos, parent, false)

        val viewHolder = ProdutoViewHolder(view)

        return viewHolder
    }

    override fun onBindViewHolder(holder: ProdutoViewHolder, position: Int) {

        val produto = produtos[position]
        holder.bindData(produto)
    }

    override fun getItemCount(): Int {
        return produtos.size
    }

    class ProdutoViewHolder( val view: View) : RecyclerView.ViewHolder(view) {

        fun bindData(produto: Produto) {

            view.name.text = produto.name

        }
    }
}