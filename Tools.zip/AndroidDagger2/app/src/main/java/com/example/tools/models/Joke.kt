package com.example.tools.models

data class Joke(
    val id: Int? = null,
    val punchline: String? = null,
    val setup: String? = null,
    val type: String? = null
)