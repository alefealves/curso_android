package com.example.tools.features.jokes

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.tools.R
import com.example.tools.models.Joke
import kotlinx.android.synthetic.main.jokes_item.view.*

class JokeAdapter : RecyclerView.Adapter<JokeAdapter.JokeViewHolder>() {

    private val jokes: MutableList<Joke> = mutableListOf()

    fun setData(jokes: MutableList<Joke>){
        this.jokes.addAll(jokes)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JokeViewHolder {

        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.fragment_jokes_detail, parent, false)

        val viewHolder = JokeViewHolder(view)

        return viewHolder
    }

    override fun onBindViewHolder(holder: JokeViewHolder, position: Int) {

        val jokes = jokes[position]
        holder.bindData(jokes)
    }

    override fun getItemCount(): Int {
        return jokes.size
    }

    class JokeViewHolder( val view: View) : RecyclerView.ViewHolder(view) {

        fun bindData(joke: Joke) {

            view.punchline.text = joke.punchline
            view.setup.text = joke.setup
            view.type.text = joke.type

        }
    }
}