package com.example.aulajson

class ParserJson {

}