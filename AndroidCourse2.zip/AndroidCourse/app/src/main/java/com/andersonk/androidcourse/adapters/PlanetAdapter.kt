package com.andersonk.androidcourse.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.andersonk.androidcourse.R
import com.andersonk.androidcourse.models.Result
import kotlinx.android.synthetic.main.planet_item.view.*

class PlanetAdapter : RecyclerView.Adapter<PlanetAdapter.planetHolder>() {

    val planets = mutableListOf<Result>()

    fun setPlanets(planets : MutableList<Result>){
        this.planets.addAll(planets)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): planetHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.planet_item, parent, false)
        return PlanetAdapter.planetHolder(view)
    }

    override fun getItemCount(): Int {
        return planets.size
    }

    override fun onBindViewHolder(holder: planetHolder, position: Int) {
        val planet = planets[position]
        holder.setPlanets(planet)
    }

    class planetHolder(private val view : View) : RecyclerView.ViewHolder(view){
        fun setPlanets(planet : Result){

            view.climate.text = planet.climate.toString()
            view.created.text = planet.created.toString()
            view.diameter.text = planet.diameter.toString()
            view.edited.text = planet.edited.toString()
            view.films.text = planet.films.toString()
            view.gravity.text = planet.gravity.toString()
            view.name.text = planet.name.toString()
            view.orbital_period.text = planet.orbital_period.toString()
            view.population.text = planet.population.toString()
            view.residents.text = planet.residents.toString()
            view.rotation_period.text = planet.rotation_period.toString()
            view.surface_water.text = planet.surface_water.toString()
            view.terrain.text = planet.terrain.toString()
            view.url.text = planet.url.toString()

            /*view.owner_name.text = question.owner?.display_name
            view.question_published.text = "6 hours ago"
            view.title.text = question.title

            view.views_label.text = question?.view_count.toString()
            view.votes_label.text = question?.score.toString()
            view.answers_label.text = question?.answer_count.toString()

            question.tags?.forEach {

                val chip = Chip(view.context)

                chip.apply {
                    chip.isClickable = false
                    chip.isCheckable = false
                    chip.chipCornerRadius = maxOf(.0f, .0f)
                    chip.text = it
                    view.labels.addView(chip)
                }
            }*/

        }
    }
}