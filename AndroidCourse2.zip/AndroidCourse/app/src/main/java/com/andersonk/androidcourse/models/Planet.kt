package com.andersonk.androidcourse.models

data class Planet(
    val count: Int? = null,
    val next: String? = null,
    val previous: Any? = null,
    val results: MutableList<Result?>? = null
)