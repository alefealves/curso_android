package com.andersonk.androidcourse

import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.andersonk.androidcourse.adapters.PlanetAdapter
import com.andersonk.androidcourse.models.Results
import com.andersonk.androidcourse.services.Api
import kotlinx.android.synthetic.main.activity_stack.*
import kotlinx.android.synthetic.main.content_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.jackson.JacksonConverterFactory

class PlanetActivity : AppCompatActivity() {

    lateinit var planetAdapter: PlanetAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_planet)
        setSupportActionBar(toolbar)

        planetAdapter = PlanetAdapter()

        val layoutManager = LinearLayoutManager(this)

        recycle_questions.layoutManager = layoutManager
        recycle_questions.adapter = planetAdapter

        getData()
    }

    private fun getData(){

        val retrofit = Retrofit.Builder()
            .baseUrl("https://swapi.co/api/")
            .addConverterFactory(JacksonConverterFactory.create())
            .build()

        val service = retrofit.create<Api>(Api::class.java)

        val call = service.getPlanets(

        )

        call.enqueue(object : Callback<Results> {
            override fun onFailure(call: Call<Results>, t: Throwable) {
                Log.d("NETWORK", t.toString())
            }

            override fun onResponse(call: Call<Results>, response: Response<Results>) {
                when(response.code()){
                    200 -> {
                        val body = response.body()
                        body?.let{
                            planetAdapter.setplanets(it.results)
                        }
                    }
                    204 -> Log.d("NETWORK","Not content")
                }
            }

        })
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}