package com.example.vender.features.settings

import androidx.fragment.app.Fragment
import com.example.vender.R


class SettingsFragment : Fragment(R.layout.fragment_settings)
