package com.example.revisao.models

import androidx.databinding.BaseObservable
import androidx.databinding.Bindable
import androidx.databinding.library.baseAdapters.BR

data class User(private var _name : String, var email : String, var password : String) : BaseObservable(){

    var name: String

    @Bindable
    get() = _name
    set(value) {
        _name = value
        notifyPropertyChanged(BR.name)
    }
}