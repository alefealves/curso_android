package com.example.revisao.viewmodels

import android.text.Editable
import android.util.Log
import android.view.View
import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel
import androidx.navigation.findNavController
import com.example.revisao.R
import com.example.revisao.models.User

class HomeViewModel : ViewModel(){

    var user = ObservableField<User>()

    fun afterChanged(s: Editable){
        Log.d("after","depois de alterar")
    }

    fun beforeChanged(s: CharSequence, start: Int, count: Int, after: Int){
        Log.d("before","antes de alterar")
    }

    fun onChanged(s: CharSequence, start: Int, before: Int, count: Int){
        Log.d("alterar","alterando")
    }

    fun buttonClick(view: View?){
        var navController = view?.findNavController()
        navController?.navigate(R.id.nav_profile_home)
    }
}