package com.example.revisao.fragments

import androidx.fragment.app.Fragment
import com.example.revisao.R

class Profile : Fragment(R.layout.profile)