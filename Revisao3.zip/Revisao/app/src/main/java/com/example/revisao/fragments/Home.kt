package com.example.revisao.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.example.revisao.R
import com.example.revisao.databinding.HomeBinding
import com.example.revisao.models.User
import com.example.revisao.viewmodels.HomeViewModel

class Home : Fragment(){

    lateinit var binding: HomeBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)

        binding = DataBindingUtil.inflate(inflater, R.layout.home,container,false)

        val viewModel = HomeViewModel()

        binding.viewModel = viewModel
        val user = User("Alefe","teste@email","password")
        viewModel.user.set(user)

        return binding.root
    }
}